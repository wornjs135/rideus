-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: j7a603.p.ssafy.io    Database: rideus
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `kakao_id` bigint DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `phone` varchar(13) DEFAULT NULL,
  `profile_image_url` varchar(200) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `auth_provider` varchar(255) DEFAULT NULL,
  `nickname` varchar(10) DEFAULT NULL,
  `refresh_token` varchar(255) DEFAULT NULL,
  `total_distance` double DEFAULT NULL,
  `total_time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `UK_hh9kg6jti4n1eoiertn2k6qsc` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (2,'2022-09-22 15:18:38','2022-10-06 14:53:01','qospwmf@gmail.com',2428691682,'배인수','01057515232','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_110x110.jpg','ROLE_MEMBER','KAKAO','배인수1','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDY2NDU0LCJleHAiOjE2NjU2NzEyNTR9.rv-OC41CPrwN1T6YubUCriqyxUuIv8pavMTKB23Xwe7S-vzsI1wyPbQ-hng-PQE3K-H-z4EBpaJ5_oIHLI9p2A',293.392,'37697.0'),(3,'2022-09-23 08:19:38','2022-10-06 15:06:25','zazachucky@naver.com',2441124334,'문석희','01088545471','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_110x110.jpg','ROLE_MEMBER','KAKAO','자자쳐키','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDY4NzUyLCJleHAiOjE2NjU2NzM1NTJ9.B0e5y88Tm6Ep5oXwhEskxr8Z6YLRa7kkFrPfl4cCFVZzgtHZAVKFi5np3ACR_W5_Z39pnsb6aKExBwKUawVMpQ',1028.861,'5283.0'),(4,'2022-09-26 04:54:58','2022-10-06 13:07:48','koyura183982@naver.com',2444618120,'고유라','01086381550','http://k.kakaocdn.net/dn/mFHAR/btrMkHHPkac/7ckCZ3VUINMChXZzflBXT0/img_110x110.jpg','ROLE_MEMBER','KAKAO','유라고','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDY3MDM1LCJleHAiOjE2NjU2NzE4MzV9.iQ0VycT8PQSqZuahfiA92cGD3E7EJv6twRIW4yAN8xMxxWAhZvfxnfGFAuaaFQOMT1QNKjeCnV3Xyo9q4MOf1Q',474.024,'62681.0'),(6,'2022-09-28 07:14:04','2022-10-06 14:55:33','psh104404@naver.com',2463015884,'백승훈','01035981184','http://k.kakaocdn.net/dn/clUd4x/btrLhO8irGb/GBphmFLGQPwccH60rKtv8k/img_110x110.jpg','ROLE_MEMBER','KAKAO','백승훈','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDY4MTAyLCJleHAiOjE2NjU2NzI5MDJ9.xagtTbhBFtBd8fK2TczHutrv8c5AgE4EbnKezjHmK9n3frqUEOYmXvx-qxLyJG_LVtpuQf7HlaODhuAHfFFZRw',563.206,'6880.0'),(7,'2022-09-29 04:40:12','2022-10-06 14:55:19','rjeowornjs@naver.com',2462915491,'박재권','01020396329','http://k.kakaocdn.net/dn/dAQBRt/btrEMRxgveH/aDaHGtUBstZIsHW0OPsP81/img_110x110.jpg','ROLE_MEMBER','KAKAO','박재권권','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDY2OTk5LCJleHAiOjE2NjU2NzE3OTl9.ohhECnK9rIEwDS_AIyFeNleANvReAaY2tR3EsyuAKtt1jhWqQ8nD_UljiIF3i2X1ewaqy_5wrBDblXde1hK46Q',811.55,'44266.0'),(8,'2022-09-29 08:45:39','2022-09-29 08:45:39','zazachucky@daum.net',2464464462,NULL,NULL,'http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_110x110.jpg','ROLE_MEMBER','KAKAO',NULL,'eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY0NDQyMzUxLCJleHAiOjE2NjUwNDcxNTF9.BqWqmrrIpKSiVVQYKCZCxvqyTyv3KJgOFvKLk4J9_SBm_zGL6xaKOAQhTSklmUs7-JY-0ebFiUoxWfO5iazMMg',0,'0'),(9,'2022-09-29 11:56:09','2022-10-06 15:01:12','dldkgus98@naver.com',2464688600,'이아현','01028721882','http://k.kakaocdn.net/dn/IWr47/btrMbxctbrB/yavx35LPQPtGcPMmphLJM1/img_110x110.jpg','ROLE_MEMBER','KAKAO','막내온탑','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDY4NDU0LCJleHAiOjE2NjU2NzMyNTR9.x9eMEu_3GcT6RnbgTNtkVE8OqexhFegb83ezM8JvL0eC9yzm8F86tsJNQEsQ827_uFPcfIZO743gU-2p5nN6Pg',0,'0'),(10,'2022-09-30 00:51:38','2022-10-06 15:10:37','son22722@naver.com',2465205834,'손민지','01056279627','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_110x110.jpg','ROLE_MEMBER','KAKAO','손민지','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDUwNTYzLCJleHAiOjE2NjU2NTUzNjN9.fHMU09a3yYq8TsupUY1cgt0Gs5TI0tilz68dnnVJiJxGSugOyL5q9-9tfaNPcCr8drgUvFvrAehaVyN-n0y9Iw',255.52500000000003,'38427.0'),(11,'2022-10-04 01:07:36','2022-10-06 04:56:04','tjdytpq0310@nate.com',2470583032,'서요셉','01099534290','http://k.kakaocdn.net/dn/UFlWR/btrE516WC2X/Ge9sVidrK09zwrUR9VALm0/img_110x110.jpg','ROLE_MEMBER','KAKAO','셉셉','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDIyMzAwLCJleHAiOjE2NjU2MjcxMDB9.HAXEor2I9BoDBxyN3-wc-S3Mp-blqclB9fA0WCZE50mrg9z7b5gGKG3YV8XF9qJoeIW07u-19WNxGDcHIg5QFg',0.229,'104.0'),(12,'2022-10-04 03:34:10','2022-10-04 03:34:59','duaudy@naver.com',2470783392,'정여명','01086471680','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_110x110.jpg','ROLE_MEMBER','KAKAO','얌얌','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY0ODU0NDUwLCJleHAiOjE2NjU0NTkyNTB9.h8aC1LO8fJ7dzfViKtPuDExWjkuxdROhmIsUBz6LJVrAiExWOBEUytHIru_nQLAhsVsUU9Gwx1Gm_2-jSlUacg',0,'1.0'),(13,'2022-10-04 06:54:01','2022-10-06 05:42:29','hice95@nate.com',2471072629,'김민정','01011113455','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_110x110.jpg','ROLE_MEMBER','KAKAO','consultant','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDQ0MjU4LCJleHAiOjE2NjU2NDkwNTh9.DXaYPyUktl-3AsCj-L_8z4FF4pSNbjuxs1JhAHruAtIPB5ik3u0akjG50mypEx2GkhJ9XuVAx4nBJPIM3hhiuw',0,'7.0'),(14,'2022-10-05 00:23:56','2022-10-06 02:11:22','chichyun92@naver.com',2471993479,'현우','01071001722','http://k.kakaocdn.net/dn/Rhmv4/btroxpDIXUo/vTU3xkxBZOjm8fzEK0FqY1/img_110x110.jpg','ROLE_MEMBER','KAKAO','현우','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDIyMjIxLCJleHAiOjE2NjU2MjcwMjF9.n_pCzo6ckJyZ0vyDb9nc-NE_2_9rJsEEUjM5wBjEMykkql05PoXe8uIcuR_rZCHrFqbOiXWee88ZMZqfc3JI0A',0,'25.0'),(15,'2022-10-06 13:44:00','2022-10-06 13:44:00','alice6551@naver.com',2474364878,NULL,NULL,'http://k.kakaocdn.net/dn/bjGvVw/btrNYqQOYgI/JQiv1jyzsSu6rH878vJhWk/img_110x110.jpg','ROLE_MEMBER','KAKAO',NULL,'eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDYzODM5LCJleHAiOjE2NjU2Njg2Mzl9.eTIt7hyfq50A_HqDKVw8pp63oRzcJ4IZineFI7W4Gxw1cc1a-Ok7Xxi8v56eIZeMueZqDsCZn7aFT6-x_6i1_g',0,'0'),(16,'2022-10-06 14:21:18','2022-10-06 14:21:18','minih122@naver.com',2474409122,NULL,NULL,'http://k.kakaocdn.net/dn/dAV0Ch/btrKkTpWPgQ/8aabMCitvUOLpDKPgXy9c1/img_110x110.jpg','ROLE_MEMBER','KAKAO',NULL,'eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDY2MTIyLCJleHAiOjE2NjU2NzA5MjJ9.qyFVX2Oxn3Kk2VcuZL_rU_Hik9b8JUWSOx0Sz9aDlPjrgJZg5BLFNwx6hsvxSRStWgeQhOJt9lK0pWq5P_ZKuQ',0,'0'),(17,'2022-10-06 15:00:54','2022-10-06 15:03:19','msg0125@naver.com',2474448795,'권기정','01000000000','http://k.kakaocdn.net/dn/R5w6d/btrmYVpTyTN/8dMYJhVox4xiB4v2nIPB0K/img_110x110.jpg','ROLE_MEMBER','KAKAO','기저기','eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDY4NDU0LCJleHAiOjE2NjU2NzMyNTR9.x9eMEu_3GcT6RnbgTNtkVE8OqexhFegb83ezM8JvL0eC9yzm8F86tsJNQEsQ827_uFPcfIZO743gU-2p5nN6Pg',0,'10.0'),(18,'2022-10-06 15:01:02','2022-10-06 15:01:02','2sy0127@naver.com',2474448900,NULL,NULL,NULL,'ROLE_MEMBER','KAKAO',NULL,'eyJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJyaWRlLXVzIiwiaWF0IjoxNjY1MDY4NDYxLCJleHAiOjE2NjU2NzMyNjF9._QILtRaqmP7zUthxhX3Q5clHMolifQNOj_NFWXz5WMzzqVrBPznxTndunift9PuCHK3QmpJQpk-3ZWOUy3Intg',0,'0');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07  0:21:40
