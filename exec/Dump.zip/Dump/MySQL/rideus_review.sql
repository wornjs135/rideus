-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: j7a603.p.ssafy.io    Database: rideus
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `review_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  `image_url` varchar(200) DEFAULT NULL,
  `like_count` int DEFAULT NULL,
  `score` int DEFAULT NULL,
  `course_id` varchar(255) DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  `record_id` varchar(255) DEFAULT NULL,
  `ride_room_id` bigint DEFAULT NULL,
  PRIMARY KEY (`review_id`),
  KEY `FKprox8elgnr8u5wrq1983degk` (`course_id`),
  KEY `FKk0ccx5i4ci2wd70vegug074w1` (`member_id`),
  KEY `FK25stjoqh46w9xqc52xyyqfk0d` (`record_id`),
  KEY `FKc8d0nnh3s5s1hwaayu8ah3scf` (`ride_room_id`),
  CONSTRAINT `FK25stjoqh46w9xqc52xyyqfk0d` FOREIGN KEY (`record_id`) REFERENCES `record` (`record_id`),
  CONSTRAINT `FKc8d0nnh3s5s1hwaayu8ah3scf` FOREIGN KEY (`ride_room_id`) REFERENCES `ride_room` (`ride_room_id`),
  CONSTRAINT `FKk0ccx5i4ci2wd70vegug074w1` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`),
  CONSTRAINT `FKprox8elgnr8u5wrq1983degk` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,'2022-09-29 04:45:16','2022-09-29 04:45:16','중간에 편의점 많아서 좋았어요!',NULL,13,5,'6333f486b46a130e57679f51',4,'633503017df17eb3c2b2babc',1),(3,'2022-09-29 04:58:35','2022-09-30 00:18:49','자전거 도로가 잘 깔려있어서 편하게 라이딩 즐기실 수 있어요!',NULL,7,4,'6333f486b46a130e57679f51',2,'633504be75ba3267838726c2',6),(4,'2022-09-29 05:01:11','2022-09-29 05:01:11','라이딩 동호회에서 최애 코스로 선정, 풍경이 너무 좋아요~!!',NULL,3,5,'6333f486b46a130e57679f51',4,'6334fdad7df17eb3c2b2bab7',2),(5,'2022-09-29 05:08:54','2022-09-29 05:08:54','밤 10시쯤 갔었는데 자전거 타는 사람들 많았음',NULL,9,4,'6333f486b46a130e57679f51',7,'633523e17df17eb3c2b2bac1',4),(6,'2022-09-29 06:04:52','2022-09-29 06:04:52','마지막 언덕 오르느라 죽을 뻔,,',NULL,11,4,'6333f486b46a130e57679f51',2,'63352f4d7df17eb3c2b2bac9',8),(7,'2022-09-29 06:12:33','2022-09-29 06:12:33','완주 못해서 아쉽습니다ㅜㅜ',NULL,2,3,'6333f486b46a130e57679f51',4,'633530317df17eb3c2b2bacb',8),(8,'2022-09-29 19:16:12','2022-09-29 19:16:12','코스 좋아요!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/f0d9d1e7-e770-4065-aa36-dde80d96da50',0,5,'633428b76617c21df3c8279a',3,'6335ee8f9cf9052c9010e641',54),(9,'2022-09-30 01:51:10','2022-09-30 01:51:10','쭉 평지라서 좋았어요~',NULL,1,5,'633428b76617c21df3c8279a',4,'633649b50f14f11b7b7b24ac',58),(10,'2022-09-30 01:53:46','2022-09-30 01:53:46','가는 길에 예쁜 카페 많음 ㅎ',NULL,0,5,'633428b76617c21df3c8279a',10,'633649e10f14f11b7b7b24ad',58),(12,'2022-09-30 02:22:31','2022-09-30 02:22:31','코스 길어서 힘들었는데 종점 풍경이 진짜 예뻤어요!',NULL,2,4,'633428b76617c21df3c8279a',4,'63364cf20f14f11b7b7b24ae',61),(13,'2022-09-30 02:24:48','2022-09-30 02:24:48','코스 초반에만 화장실이 있어요ㅜㅜ',NULL,2,3,'633428b76617c21df3c8279a',2,'63364d050f14f11b7b7b24af',61),(14,'2022-09-30 02:24:55','2022-09-30 02:24:55','업힐 다운힐 골고루 있음',NULL,2,5,'633428b76617c21df3c8279a',7,'63364d190f14f11b7b7b24b0',61),(15,'2022-09-30 02:27:00','2022-09-30 02:27:00','코스 한적하고 좋아요!',NULL,2,5,'633428b76617c21df3c8279a',10,'63364d320f14f11b7b7b24b1',61),(16,'2022-10-01 15:15:35','2022-10-01 15:15:35','코스 리뷰 덤프','https://rideus-image.s3.ap-northeast-2.amazonaws.com/ce25d298-83e5-482e-be71-881f287c3628',0,2,'63384a0498bdd80eb8a5510c',6,'6338596c98bdd80eb8a55115',79),(17,'2022-10-01 15:22:11','2022-10-01 15:22:11','코스리뷰','https://rideus-image.s3.ap-northeast-2.amazonaws.com/f6af18d8-99c5-4e9e-9af9-0193c35c88de',0,4,'6333f48db46a130e57679f7b',6,'63385b0a98bdd80eb8a55118',82),(18,'2022-10-01 15:23:05','2022-10-01 15:23:05','소래포구 리뷰','https://rideus-image.s3.ap-northeast-2.amazonaws.com/759933c1-7c21-4a92-b184-b3ff03470065',0,4,'633428b76617c21df3c8279a',6,'63385b4498bdd80eb8a55119',83),(19,'2022-10-01 18:47:39','2022-10-01 18:47:39','','https://rideus-image.s3.ap-northeast-2.amazonaws.com/7ce57e1f-eb04-4883-b970-ea4c7d698c30',0,5,'6333f486b46a130e57679f51',3,'63388ae798bdd80eb8a55127',96),(20,'2022-10-02 01:53:16','2022-10-02 01:53:16','바람이 적당히 불어서 시원해요!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/a7df24b4-0211-49db-84c1-a15894499a35',0,5,'633428b76617c21df3c8279a',7,'6338eee71919e353b2c9da54',102),(21,'2022-10-04 05:41:27','2022-10-04 05:41:27','너무 재밌어요!!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/4398830b-94cc-458e-b6f8-758add47da69',0,3,'633a643c5a92c8495069b2c2',6,'633bc616a331ae3fc18668d1',133),(22,'2022-10-04 05:41:27','2022-10-04 05:41:27','너무 재밌어요!!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/e820b82a-cbf0-4525-95ad-0397ad2304b3',0,3,'633a643c5a92c8495069b2c2',6,'633bc616a331ae3fc18668d1',133),(23,'2022-10-06 04:48:56','2022-10-06 04:48:56','시원하고 너무 좋아요!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/e8858549-57c4-4e5d-a082-bd806f3def48',0,5,'633428b76617c21df3c8279a',7,'633e5dac028dd2146f6db513',215),(24,'2022-10-06 04:49:04','2022-10-06 04:49:04','한강뷰가 너무 좋아요!!?','https://rideus-image.s3.ap-northeast-2.amazonaws.com/fdd91f35-8dd1-4642-9593-4e77bd701156',0,4,'633428b76617c21df3c8279a',6,'633e5daa028dd2146f6db512',215),(25,'2022-10-06 04:49:40','2022-10-06 04:49:40','같이 타면은 재밌어요!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/07276df2-ce64-4640-89a2-3f2dca19cd99',0,5,'633428b76617c21df3c8279a',2,'633e5e39028dd2146f6db515',215),(26,'2022-10-06 04:49:48','2022-10-06 04:49:48','날씨 굿 코스도 구웃!!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/9a63ad55-1bb1-4db2-86e2-c6d5e783aa2b',0,4,'633428b76617c21df3c8279a',10,'633e5dce028dd2146f6db514',215),(27,'2022-10-06 05:57:04','2022-10-06 05:57:04','초보자들도 쉽게 탈 수 있는 코스입니다! 시원하고 경치도 좋아요!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/bb5ccb56-4da4-45bd-8862-066d19e0c2e9',0,5,'633e6bd2028dd2146f6db51b',7,'633e6de4028dd2146f6db524',221),(28,'2022-10-06 05:57:20','2022-10-06 05:57:20','신반포 너무 좋아요!!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/d0388543-87c6-4f4b-8f69-776f1851baf4',0,4,'633e6bd2028dd2146f6db51b',6,'633e6e1a028dd2146f6db527',221),(29,'2022-10-06 06:25:44','2022-10-06 06:25:44','주변 라이더들 너무 멋있어요??','https://rideus-image.s3.ap-northeast-2.amazonaws.com/81474ff5-37d8-4974-bedf-cb251ea0409f',0,4,'633e6bd2028dd2146f6db51b',6,'633e74b5028dd2146f6db52b',223),(30,'2022-10-06 06:43:23','2022-10-06 06:43:23','한가한 편이라 자전거 타기 좋았어요!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/5969ea7d-6655-4085-aa51-69ad2d6b36e6',0,5,'633e6bd2028dd2146f6db51b',7,'633e78bc028dd2146f6db531',227),(31,'2022-10-06 06:46:07','2022-10-06 06:46:07','좋아용!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/66cbf14d-65b1-4237-aeb5-5f3fa36c5b60',0,5,'633e6bd2028dd2146f6db51b',2,'633e7897028dd2146f6db530',227),(32,'2022-10-06 07:13:38','2022-10-06 07:13:38','너무 재미있는 코스에요!!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/fb4c115a-fba3-4aab-8b86-c3ea45ce269a',0,5,'633e6bd2028dd2146f6db51b',7,'633e7fee03faa71935a355e4',228),(33,'2022-10-06 07:14:12','2022-10-06 07:14:12','재밌어용!!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/f398d006-0cb5-4a06-9da9-aae45a88690c',0,5,'633e6bd2028dd2146f6db51b',2,'633e7fe603faa71935a355e3',228),(34,'2022-10-06 07:28:54','2022-10-06 07:28:54','주말에는 사람이 쫌 많아요! 하지만 재밌어요!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/6a61d755-f75a-4503-a0ca-cf3adef89d4b',0,5,'633e6bd2028dd2146f6db51b',7,'633e838703faa71935a355e6',229),(35,'2022-10-06 07:29:20','2022-10-06 07:29:20','재밌어용!! 문석희 화이팅!!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/e478d718-8e31-4812-bcb3-a2d075e0b658',0,5,'633e6bd2028dd2146f6db51b',2,'633e838103faa71935a355e5',229),(36,'2022-10-06 07:53:00','2022-10-06 07:53:00','매우 선선하고 평지라 자전거 타기 편해요!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/2062f3a9-53c5-41cb-9a41-66f32ef58f53',0,5,'633e6bd2028dd2146f6db51b',7,'633e893703faa71935a355ea',232),(37,'2022-10-06 07:53:21','2022-10-06 07:53:21','코스가 쾌적하고 좋아요!!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/92dbc348-729f-4cb6-9102-d41156bf0f39',0,5,'633e6bd2028dd2146f6db51b',2,'633e893303faa71935a355e9',232),(38,'2022-10-06 07:59:08','2022-10-06 07:59:08','같이 타니 즐거워요 :D  코스 무난해서 초보자에게 좋아요!','https://rideus-image.s3.ap-northeast-2.amazonaws.com/1e38b6a3-bb65-4a9e-8df7-158f518d7937',0,5,'633e6bd2028dd2146f6db51b',10,'633e89d503faa71935a355ec',232),(39,'2022-10-06 13:04:57','2022-10-06 13:04:57','','https://rideus-image.s3.ap-northeast-2.amazonaws.com/025ebfcd-0d10-4b82-9d00-720957d9113c',0,5,'633428b76617c21df3c8279a',3,'633ed26ff7d346532f5d032d',242),(40,'2022-10-06 13:05:28','2022-10-06 13:05:28','','https://rideus-image.s3.ap-northeast-2.amazonaws.com/9dcf5e42-4c3f-4b56-b2b7-c3034aa065e8',0,5,'633428b76617c21df3c8279a',3,'633ed28ff7d346532f5d032e',243),(41,'2022-10-06 13:07:28','2022-10-06 13:07:28','','https://rideus-image.s3.ap-northeast-2.amazonaws.com/1695def2-6a7c-411e-85aa-370dafe82dcb',0,5,'633428b76617c21df3c8279a',4,'633ed2ebf7d346532f5d032f',244),(42,'2022-10-06 13:13:56','2022-10-06 13:13:56','초보인 저한텐 길지만 자전거 도로도 있고 신호도 없고 아주 좋아요~','https://rideus-image.s3.ap-northeast-2.amazonaws.com/59f74f1b-06a6-4f5c-b5a6-6086db4dd792',0,3,'633428b76617c21df3c8279a',10,'633ed3bff7d346532f5d0331',246),(43,'2022-10-06 13:16:06','2022-10-06 13:16:06','이 코스 좋습니다! 자주 타요~','https://rideus-image.s3.ap-northeast-2.amazonaws.com/b7085342-5961-4bd6-9f5e-248973818deb',0,3,'633428b76617c21df3c8279a',10,'633ed4c8f7d346532f5d0334',249);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07  0:21:39
